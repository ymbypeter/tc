<template>
    <div>
        <button @click="status = !status">aaa</button>
    </div>
</template>

<script>
export default{
    data: () => {
        return {
            status: false
        }
    }
}
</script>

<style>

</style>